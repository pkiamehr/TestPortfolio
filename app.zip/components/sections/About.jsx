"use client";

import Image from "next/image";
import { motion } from "motion/react";
import { assets, toolsData } from "@utils/assets";
import { useTheme } from "@providers/ThemeProvider";

export default function About({ dict }) {
  const { isDarkMode } = useTheme();

  return (
    <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ duration: 1 }} id="about" className=" w-full px-[12%] py-4 scroll-mt-16">
      َ
      <motion.h4 initial={{ y: -20, opacity: 0 }} whileInView={{ y: 0, opacity: 1 }} transition={{ duration: 0.5, delay: 0.1 }} className=" text-center mb-2 text-lg font-Ovo">
        {dict.aboutme.h4}
      </motion.h4>
      <motion.h2 initial={{ y: -20, opacity: 0 }} whileInView={{ y: 0, opacity: 1 }} transition={{ duration: 0.5, delay: 0.3 }} className=" text-center text-5xl font-Ovo">
        {dict.aboutme.title}
      </motion.h2>
      <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ duration: 0.8 }} className=" flex w-full flex-col lg:flex-row items-center gap-20 my-15">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} whileInView={{ scale: 1, opacity: 1 }} transition={{ duration: 0.6 }} className=" w-64 sm:w-80 rounded-3xl max-w-none">
          <Image src={assets.user_img} alt="kiamehr" className=" w-full rounded-3xl" />
        </motion.div>
        <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.5 }} className=" flex-1">
          <p className=" mb-10 max-w-2xl font-Ovo ">{dict.aboutme.description}</p>
          <motion.ul initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ duration: 0.8, delay: 0.8 }} className=" grid grid-cols-1 sm:grid-cols-3 sm:text-base gap-6 max-w-2xl">
            <motion.li
              whileHover={{ scale: 1.05 }}
              className="border-[0.5px] border-gray-500 rounded-xl p-4 sm:p-6 cursor-pointer hover:bg-lightHover hover:-translate-y-1 duration-500 hover:shadow-black dark:border-white dark:hover:shadow-white dark:hover:bg-darkHover/50"
            >
              <Image src={isDarkMode ? assets.code_icon_dark : assets.code_icon} alt={dict.aboutme.boxtitle1} className="w-7 mt-3" />
              <h3 className="my-4 font-semibold text-gray-700 dark:text-white">{dict.aboutme.boxtitle1}</h3>
              <p className="text-gray-600 text-sm sm:text-base dark:text-white/80 w-full leading-6 break-words whitespace-normal">{dict.aboutme.boxdescription1}</p>
            </motion.li>
            <motion.li
              whileHover={{ scale: 1.05 }}
              className="border-[0.5px] border-gray-500 rounded-xl p-4 sm:p-6 cursor-pointer hover:bg-lightHover hover:-translate-y-1 duration-500 hover:shadow-black dark:border-white dark:hover:shadow-white dark:hover:bg-darkHover/50"
            >
              <Image src={isDarkMode ? assets.code_icon_dark : assets.code_icon} alt={dict.aboutme.boxtitle2} className="w-7 mt-3" />
              <h3 className="my-4 font-semibold text-gray-700 dark:text-white">{dict.aboutme.boxtitle2}</h3>
              <p className="text-gray-600 text-sm sm:text-base dark:text-white/80 w-full leading-6 break-words whitespace-normal">{dict.aboutme.boxdescription2}</p>
            </motion.li>
            <motion.li
              whileHover={{ scale: 1.05 }}
              className="border-[0.5px] border-gray-500 rounded-xl p-4 sm:p-6 cursor-pointer hover:bg-lightHover hover:-translate-y-1 duration-500 hover:shadow-black dark:border-white dark:hover:shadow-white dark:hover:bg-darkHover/50"
            >
              <Image src={isDarkMode ? assets.project_icon_dark : assets.project_icon} alt={dict.aboutme.boxtitle3} className="w-7 mt-3" />
              <h3 className="my-4 font-semibold text-gray-700 dark:text-white">{dict.aboutme.boxtitle3}</h3>
              <p className="text-gray-600 text-sm sm:text-base dark:text-white/80 w-full leading-6 break-words whitespace-normal">{dict.aboutme.boxdescription3}</p>
            </motion.li>
          </motion.ul>
          <motion.h4 initial={{ y: 20, opacity: 0 }} whileInView={{ y: 0, opacity: 1 }} transition={{ duration: 0.5, delay: 0.8 }} className=" my-6 text-gray-700 font-Ovo dark:text-white/80">
            {dict.aboutme.tools}
          </motion.h4>
          <motion.ul initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.7 }} className=" flex items-center gap-3 sm:gap-5">
            {toolsData.map((tool, index) => (
              <motion.li
                whileHover={{ scale: 1.1 }}
                key={index}
                className=" flex items-center justify-center w-12 sm:w-14 aspect-square border border-gray-400 rounded-lg cursor-pointer hover:-translate-y-1 duration-500"
              >
                <Image src={tool} alt="tools" className=" w-6 h-6 sm:w-7" />
              </motion.li>
            ))}
          </motion.ul>
        </motion.div>
      </motion.div>
    </motion.div>
  );
}
